# Farmers Connector - Farm Management Marketplace

## Overview
Farmers Connector is a comprehensive farm management marketplace platform that connects farmers with suppliers, service providers, and buyers. The platform offers tools for farm management, inventory tracking, financial management, and market access.

## Author
**Mordecai Musinahama**
- Lead Developer & Project Manager
- Pique Squid Consultancy

## Copyright
© 2024 Pique Squid Consultancy. All rights reserved.

## Features
- Farm Management Dashboard
- Inventory Management
- Financial Tracking
- Market Access Platform
- Supplier Network
- Mobile Responsive Design

## Technology Stack
- HTML5
- CSS3
- JavaScript
- PHP
- Bootstrap 5
- Font Awesome
- Google reCAPTCHA
- PHPMailer

## Installation
1. Clone the repository
2. Configure your web server (Apache/Nginx)
3. Set up PHP environment
4. Configure SMTP settings in PHP files
5. Update reCAPTCHA keys

## Configuration
### SMTP Settings
Update the following in PHP files:
```php
$mail->Host = 'your-smtp-host';
$mail->Username = 'your-email';
$mail->Password = 'your-password';
```

### reCAPTCHA
Add your reCAPTCHA keys:
- Site Key: 6LeccVgrAAAAAEwE1KU0fI-Y3GYN2uy8wZN58HT-
- Secret Key: 6LeccVgrAAAAAPhhaa7xBjDZD6xDm69qz_iz6P7Y

## Contact
For support or inquiries, please contact:
- Email: gmatanda@piquesquid.com
- Phone: +254 123 456 789

## License
This project is proprietary software owned by Pique Squid Consultancy. Unauthorized copying, distribution, or use is strictly prohibited.


