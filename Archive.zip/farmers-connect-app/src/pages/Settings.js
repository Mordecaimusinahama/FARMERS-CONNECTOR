import React from 'react';

const Settings = () => (
  <div className="p-8 animate-slide-up">
    <h2 className="text-2xl font-heading text-primary-700 mb-4">Settings & Customization</h2>
    <p className="text-primary-900">Language, themes, and preferences coming soon!</p>
  </div>
);

export default Settings; 