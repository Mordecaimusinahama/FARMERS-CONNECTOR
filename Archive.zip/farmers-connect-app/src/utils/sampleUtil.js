export function greetUser(name) {
  return `Hello, ${name}! Welcome to Farmers Connector.`;
} 